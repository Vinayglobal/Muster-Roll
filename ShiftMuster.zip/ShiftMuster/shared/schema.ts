import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const employees = pgTable("employees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  department: text("department").notNull(),
  position: text("position").notNull(),
  phone: text("phone"),
  status: text("status").notNull().default("active"), // active, inactive, on-leave
  createdAt: timestamp("created_at").defaultNow(),
});

export const shiftTypes = pgTable("shift_types", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  startTime: text("start_time").notNull(), // "06:00"
  endTime: text("end_time").notNull(), // "14:00"
  description: text("description"),
});

export const shifts = pgTable("shifts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shiftTypeId: varchar("shift_type_id").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  department: text("department").notNull(),
  requiredStaff: integer("required_staff").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const shiftAssignments = pgTable("shift_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shiftId: varchar("shift_id").notNull(),
  employeeId: varchar("employee_id").notNull(),
  status: text("status").notNull().default("scheduled"), // scheduled, confirmed, completed
  createdAt: timestamp("created_at").defaultNow(),
});

export const attendance = pgTable("attendance", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull(),
  shiftId: varchar("shift_id").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD
  checkIn: text("check_in"), // "06:00"
  checkOut: text("check_out"), // "14:00"
  status: text("status").notNull(), // present, absent, late, partial
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const shiftTemplates = pgTable("shift_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  department: text("department").notNull(),
  morningStaff: integer("morning_staff").default(0),
  afternoonStaff: integer("afternoon_staff").default(0),
  nightStaff: integer("night_staff").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  lastUsed: timestamp("last_used"),
});

// Insert schemas
export const insertEmployeeSchema = createInsertSchema(employees).omit({
  id: true,
  createdAt: true,
}).extend({
  employeeId: z.string().min(1, "Employee ID is required"),
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email format"),
  department: z.string().min(1, "Department is required"),
  position: z.string().min(1, "Position is required"),
  status: z.enum(["active", "inactive", "on-leave"]).default("active"),
});

export const insertShiftTypeSchema = createInsertSchema(shiftTypes).omit({
  id: true,
}).extend({
  name: z.string().min(1, "Shift name is required"),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, "Time must be in HH:MM format"),
  endTime: z.string().regex(/^\d{2}:\d{2}$/, "Time must be in HH:MM format"),
});

export const insertShiftSchema = createInsertSchema(shifts).omit({
  id: true,
  createdAt: true,
}).extend({
  shiftTypeId: z.string().min(1, "Shift type is required"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  department: z.string().min(1, "Department is required"),
  requiredStaff: z.number().min(1, "Required staff must be at least 1"),
});

export const insertShiftAssignmentSchema = createInsertSchema(shiftAssignments).omit({
  id: true,
  createdAt: true,
}).extend({
  shiftId: z.string().min(1, "Shift ID is required"),
  employeeId: z.string().min(1, "Employee ID is required"),
  status: z.enum(["scheduled", "confirmed", "completed"]).default("scheduled"),
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  createdAt: true,
}).extend({
  employeeId: z.string().min(1, "Employee ID is required"),
  shiftId: z.string().min(1, "Shift ID is required"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  status: z.enum(["present", "absent", "late", "partial"]),
  checkIn: z.string().regex(/^\d{2}:\d{2}$/, "Time must be in HH:MM format").optional(),
  checkOut: z.string().regex(/^\d{2}:\d{2}$/, "Time must be in HH:MM format").optional(),
});

export const insertShiftTemplateSchema = createInsertSchema(shiftTemplates).omit({
  id: true,
  createdAt: true,
  lastUsed: true,
}).extend({
  name: z.string().min(1, "Template name is required"),
  department: z.string().min(1, "Department is required"),
  morningStaff: z.number().min(0).default(0),
  afternoonStaff: z.number().min(0).default(0),
  nightStaff: z.number().min(0).default(0),
  isActive: z.boolean().default(true),
});

// Types
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;

export type InsertShiftType = z.infer<typeof insertShiftTypeSchema>;
export type ShiftType = typeof shiftTypes.$inferSelect;

export type InsertShift = z.infer<typeof insertShiftSchema>;
export type Shift = typeof shifts.$inferSelect;

export type InsertShiftAssignment = z.infer<typeof insertShiftAssignmentSchema>;
export type ShiftAssignment = typeof shiftAssignments.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

export type InsertShiftTemplate = z.infer<typeof insertShiftTemplateSchema>;
export type ShiftTemplate = typeof shiftTemplates.$inferSelect;

// User types for authentication
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
