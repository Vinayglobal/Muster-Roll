import { 
  type Employee, type InsertEmployee,
  type ShiftType, type InsertShiftType,
  type Shift, type InsertShift,
  type ShiftAssignment, type InsertShiftAssignment,
  type Attendance, type InsertAttendance,
  type ShiftTemplate, type InsertShiftTemplate,
  type User, type UpsertUser,
  users
} from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User methods (for authentication)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Employee methods
  getEmployee(id: string): Promise<Employee | undefined>;
  getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined>;
  getAllEmployees(): Promise<Employee[]>;
  getEmployeesByDepartment(department: string): Promise<Employee[]>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: string, updates: Partial<InsertEmployee>): Promise<Employee | undefined>;
  deleteEmployee(id: string): Promise<boolean>;

  // Shift Type methods
  getAllShiftTypes(): Promise<ShiftType[]>;
  getShiftType(id: string): Promise<ShiftType | undefined>;
  createShiftType(shiftType: InsertShiftType): Promise<ShiftType>;

  // Shift methods
  getAllShifts(): Promise<Shift[]>;
  getShift(id: string): Promise<Shift | undefined>;
  getShiftsByDate(date: string): Promise<Shift[]>;
  getShiftsByDateRange(startDate: string, endDate: string): Promise<Shift[]>;
  createShift(shift: InsertShift): Promise<Shift>;
  updateShift(id: string, updates: Partial<InsertShift>): Promise<Shift | undefined>;
  deleteShift(id: string): Promise<boolean>;

  // Shift Assignment methods
  getAllShiftAssignments(): Promise<ShiftAssignment[]>;
  getShiftAssignmentsByShift(shiftId: string): Promise<ShiftAssignment[]>;
  getShiftAssignmentsByEmployee(employeeId: string): Promise<ShiftAssignment[]>;
  createShiftAssignment(assignment: InsertShiftAssignment): Promise<ShiftAssignment>;
  deleteShiftAssignment(id: string): Promise<boolean>;

  // Attendance methods
  getAllAttendance(): Promise<Attendance[]>;
  getAttendanceByDate(date: string): Promise<Attendance[]>;
  getAttendanceByEmployee(employeeId: string): Promise<Attendance[]>;
  getAttendanceByShift(shiftId: string): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: string, updates: Partial<InsertAttendance>): Promise<Attendance | undefined>;

  // Shift Template methods
  getAllShiftTemplates(): Promise<ShiftTemplate[]>;
  getShiftTemplate(id: string): Promise<ShiftTemplate | undefined>;
  createShiftTemplate(template: InsertShiftTemplate): Promise<ShiftTemplate>;
  updateShiftTemplate(id: string, updates: Partial<InsertShiftTemplate>): Promise<ShiftTemplate | undefined>;
  deleteShiftTemplate(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User methods (for authentication)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
  private employees: Map<string, Employee> = new Map();
  private shiftTypes: Map<string, ShiftType> = new Map();
  private shifts: Map<string, Shift> = new Map();
  private shiftAssignments: Map<string, ShiftAssignment> = new Map();
  private attendance: Map<string, Attendance> = new Map();
  private shiftTemplates: Map<string, ShiftTemplate> = new Map();

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize default shift types
    const morningShift: ShiftType = {
      id: "shift-morning",
      name: "Morning Shift",
      startTime: "06:00",
      endTime: "14:00",
      description: "Standard morning shift"
    };

    const afternoonShift: ShiftType = {
      id: "shift-afternoon", 
      name: "Afternoon Shift",
      startTime: "14:00",
      endTime: "22:00",
      description: "Standard afternoon shift"
    };

    const nightShift: ShiftType = {
      id: "shift-night",
      name: "Night Shift", 
      startTime: "22:00",
      endTime: "06:00",
      description: "Standard night shift"
    };

    this.shiftTypes.set(morningShift.id, morningShift);
    this.shiftTypes.set(afternoonShift.id, afternoonShift);
    this.shiftTypes.set(nightShift.id, nightShift);
  }

  // Employee methods
  async getEmployee(id: string): Promise<Employee | undefined> {
    return this.employees.get(id);
  }

  async getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined> {
    return Array.from(this.employees.values()).find(emp => emp.employeeId === employeeId);
  }

  async getAllEmployees(): Promise<Employee[]> {
    return Array.from(this.employees.values());
  }

  async getEmployeesByDepartment(department: string): Promise<Employee[]> {
    return Array.from(this.employees.values()).filter(emp => emp.department === department);
  }

  async createEmployee(insertEmployee: InsertEmployee): Promise<Employee> {
    const id = randomUUID();
    const employee: Employee = {
      ...insertEmployee,
      id,
      phone: insertEmployee.phone || null,
      createdAt: new Date(),
    };
    this.employees.set(id, employee);
    return employee;
  }

  async updateEmployee(id: string, updates: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const employee = this.employees.get(id);
    if (!employee) return undefined;

    const updatedEmployee = { ...employee, ...updates };
    this.employees.set(id, updatedEmployee);
    return updatedEmployee;
  }

  async deleteEmployee(id: string): Promise<boolean> {
    return this.employees.delete(id);
  }

  // Shift Type methods
  async getAllShiftTypes(): Promise<ShiftType[]> {
    return Array.from(this.shiftTypes.values());
  }

  async getShiftType(id: string): Promise<ShiftType | undefined> {
    return this.shiftTypes.get(id);
  }

  async createShiftType(insertShiftType: InsertShiftType): Promise<ShiftType> {
    const id = randomUUID();
    const shiftType: ShiftType = { 
      ...insertShiftType, 
      id,
      description: insertShiftType.description || null
    };
    this.shiftTypes.set(id, shiftType);
    return shiftType;
  }

  // Shift methods
  async getAllShifts(): Promise<Shift[]> {
    return Array.from(this.shifts.values());
  }

  async getShift(id: string): Promise<Shift | undefined> {
    return this.shifts.get(id);
  }

  async getShiftsByDate(date: string): Promise<Shift[]> {
    return Array.from(this.shifts.values()).filter(shift => shift.date === date);
  }

  async getShiftsByDateRange(startDate: string, endDate: string): Promise<Shift[]> {
    return Array.from(this.shifts.values()).filter(shift => 
      shift.date >= startDate && shift.date <= endDate
    );
  }

  async createShift(insertShift: InsertShift): Promise<Shift> {
    const id = randomUUID();
    const shift: Shift = {
      ...insertShift,
      id,
      notes: insertShift.notes || null,
      createdAt: new Date(),
    };
    this.shifts.set(id, shift);
    return shift;
  }

  async updateShift(id: string, updates: Partial<InsertShift>): Promise<Shift | undefined> {
    const shift = this.shifts.get(id);
    if (!shift) return undefined;

    const updatedShift = { ...shift, ...updates };
    this.shifts.set(id, updatedShift);
    return updatedShift;
  }

  async deleteShift(id: string): Promise<boolean> {
    return this.shifts.delete(id);
  }

  // Shift Assignment methods
  async getAllShiftAssignments(): Promise<ShiftAssignment[]> {
    return Array.from(this.shiftAssignments.values());
  }

  async getShiftAssignmentsByShift(shiftId: string): Promise<ShiftAssignment[]> {
    return Array.from(this.shiftAssignments.values()).filter(assignment => assignment.shiftId === shiftId);
  }

  async getShiftAssignmentsByEmployee(employeeId: string): Promise<ShiftAssignment[]> {
    return Array.from(this.shiftAssignments.values()).filter(assignment => assignment.employeeId === employeeId);
  }

  async createShiftAssignment(insertAssignment: InsertShiftAssignment): Promise<ShiftAssignment> {
    const id = randomUUID();
    const assignment: ShiftAssignment = {
      ...insertAssignment,
      id,
      createdAt: new Date(),
    };
    this.shiftAssignments.set(id, assignment);
    return assignment;
  }

  async deleteShiftAssignment(id: string): Promise<boolean> {
    return this.shiftAssignments.delete(id);
  }

  // Attendance methods
  async getAllAttendance(): Promise<Attendance[]> {
    return Array.from(this.attendance.values());
  }

  async getAttendanceByDate(date: string): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(record => record.date === date);
  }

  async getAttendanceByEmployee(employeeId: string): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(record => record.employeeId === employeeId);
  }

  async getAttendanceByShift(shiftId: string): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(record => record.shiftId === shiftId);
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = randomUUID();
    const attendance: Attendance = {
      ...insertAttendance,
      id,
      notes: insertAttendance.notes || null,
      checkIn: insertAttendance.checkIn || null,
      checkOut: insertAttendance.checkOut || null,
      createdAt: new Date(),
    };
    this.attendance.set(id, attendance);
    return attendance;
  }

  async updateAttendance(id: string, updates: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const record = this.attendance.get(id);
    if (!record) return undefined;

    const updatedRecord = { ...record, ...updates };
    this.attendance.set(id, updatedRecord);
    return updatedRecord;
  }

  // Shift Template methods
  async getAllShiftTemplates(): Promise<ShiftTemplate[]> {
    return Array.from(this.shiftTemplates.values()).filter(template => template.isActive);
  }

  async getShiftTemplate(id: string): Promise<ShiftTemplate | undefined> {
    return this.shiftTemplates.get(id);
  }

  async createShiftTemplate(insertTemplate: InsertShiftTemplate): Promise<ShiftTemplate> {
    const id = randomUUID();
    const template: ShiftTemplate = {
      ...insertTemplate,
      id,
      description: insertTemplate.description || null,
      morningStaff: insertTemplate.morningStaff || null,
      afternoonStaff: insertTemplate.afternoonStaff || null,
      nightStaff: insertTemplate.nightStaff || null,
      isActive: insertTemplate.isActive ?? null,
      createdAt: new Date(),
      lastUsed: null,
    };
    this.shiftTemplates.set(id, template);
    return template;
  }

  async updateShiftTemplate(id: string, updates: Partial<InsertShiftTemplate>): Promise<ShiftTemplate | undefined> {
    const template = this.shiftTemplates.get(id);
    if (!template) return undefined;

    const updatedTemplate = { ...template, ...updates };
    this.shiftTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteShiftTemplate(id: string): Promise<boolean> {
    return this.shiftTemplates.delete(id);
  }
}

export const storage = new DatabaseStorage();
