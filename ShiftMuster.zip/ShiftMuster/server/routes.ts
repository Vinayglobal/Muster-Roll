import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertEmployeeSchema, 
  insertShiftSchema, 
  insertShiftAssignmentSchema,
  insertAttendanceSchema,
  insertShiftTemplateSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Protected Employee routes
  app.get("/api/employees", isAuthenticated, async (req, res) => {
    try {
      const { department } = req.query;
      let employees;
      
      if (department && typeof department === 'string') {
        employees = await storage.getEmployeesByDepartment(department);
      } else {
        employees = await storage.getAllEmployees();
      }
      
      res.json(employees);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch employees" });
    }
  });

  app.get("/api/employees/:id", isAuthenticated, async (req, res) => {
    try {
      const employee = await storage.getEmployee(req.params.id);
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.json(employee);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch employee" });
    }
  });

  app.post("/api/employees", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertEmployeeSchema.parse(req.body);
      
      // Check for duplicate employee ID
      const existingEmployee = await storage.getEmployeeByEmployeeId(validatedData.employeeId);
      if (existingEmployee) {
        return res.status(400).json({ message: "Employee ID already exists" });
      }
      
      const employee = await storage.createEmployee(validatedData);
      res.status(201).json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create employee" });
    }
  });

  app.put("/api/employees/:id", async (req, res) => {
    try {
      const validatedData = insertEmployeeSchema.partial().parse(req.body);
      const employee = await storage.updateEmployee(req.params.id, validatedData);
      
      if (!employee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      
      res.json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update employee" });
    }
  });

  app.delete("/api/employees/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteEmployee(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete employee" });
    }
  });

  // Shift Type routes
  app.get("/api/shift-types", async (req, res) => {
    try {
      const shiftTypes = await storage.getAllShiftTypes();
      res.json(shiftTypes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shift types" });
    }
  });

  // Shift routes
  app.get("/api/shifts", async (req, res) => {
    try {
      const { date, startDate, endDate } = req.query;
      let shifts;
      
      if (startDate && endDate && typeof startDate === 'string' && typeof endDate === 'string') {
        shifts = await storage.getShiftsByDateRange(startDate, endDate);
      } else if (date && typeof date === 'string') {
        shifts = await storage.getShiftsByDate(date);
      } else {
        shifts = await storage.getAllShifts();
      }
      
      res.json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shifts" });
    }
  });

  app.post("/api/shifts", async (req, res) => {
    try {
      const validatedData = insertShiftSchema.parse(req.body);
      const shift = await storage.createShift(validatedData);
      res.status(201).json(shift);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create shift" });
    }
  });

  app.delete("/api/shifts/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteShift(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Shift not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete shift" });
    }
  });

  // Shift Assignment routes
  app.get("/api/shift-assignments", async (req, res) => {
    try {
      const { shiftId, employeeId } = req.query;
      let assignments;
      
      if (shiftId && typeof shiftId === 'string') {
        assignments = await storage.getShiftAssignmentsByShift(shiftId);
      } else if (employeeId && typeof employeeId === 'string') {
        assignments = await storage.getShiftAssignmentsByEmployee(employeeId);
      } else {
        assignments = await storage.getAllShiftAssignments();
      }
      
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shift assignments" });
    }
  });

  app.post("/api/shift-assignments", async (req, res) => {
    try {
      const validatedData = insertShiftAssignmentSchema.parse(req.body);
      const assignment = await storage.createShiftAssignment(validatedData);
      res.status(201).json(assignment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create shift assignment" });
    }
  });

  app.delete("/api/shift-assignments/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteShiftAssignment(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Shift assignment not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete shift assignment" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", async (req, res) => {
    try {
      const { date, employeeId, shiftId } = req.query;
      let attendance;
      
      if (date && typeof date === 'string') {
        attendance = await storage.getAttendanceByDate(date);
      } else if (employeeId && typeof employeeId === 'string') {
        attendance = await storage.getAttendanceByEmployee(employeeId);
      } else if (shiftId && typeof shiftId === 'string') {
        attendance = await storage.getAttendanceByShift(shiftId);
      } else {
        attendance = await storage.getAllAttendance();
      }
      
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance" });
    }
  });

  app.post("/api/attendance", async (req, res) => {
    try {
      const validatedData = insertAttendanceSchema.parse(req.body);
      const attendance = await storage.createAttendance(validatedData);
      res.status(201).json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create attendance record" });
    }
  });

  app.put("/api/attendance/:id", async (req, res) => {
    try {
      const validatedData = insertAttendanceSchema.partial().parse(req.body);
      const attendance = await storage.updateAttendance(req.params.id, validatedData);
      
      if (!attendance) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      
      res.json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update attendance record" });
    }
  });

  // Muster roll generation
  app.get("/api/muster-roll/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const { shiftTypeId } = req.query;
      
      // Get shifts for the date
      const shifts = await storage.getShiftsByDate(date);
      let filteredShifts = shifts;
      
      if (shiftTypeId && typeof shiftTypeId === 'string') {
        filteredShifts = shifts.filter(shift => shift.shiftTypeId === shiftTypeId);
      }
      
      const musterRoll = [];
      
      for (const shift of filteredShifts) {
        // Get assignments for this shift
        const assignments = await storage.getShiftAssignmentsByShift(shift.id);
        
        for (const assignment of assignments) {
          const employee = await storage.getEmployee(assignment.employeeId);
          if (!employee) continue;
          
          // Get attendance record if exists
          const attendanceRecords = await storage.getAttendanceByShift(shift.id);
          const attendanceRecord = attendanceRecords.find(att => att.employeeId === employee.id);
          
          musterRoll.push({
            employee,
            shift,
            assignment,
            attendance: attendanceRecord || null
          });
        }
      }
      
      res.json(musterRoll);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate muster roll" });
    }
  });

  // Shift Template routes
  app.get("/api/shift-templates", async (req, res) => {
    try {
      const templates = await storage.getAllShiftTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shift templates" });
    }
  });

  app.post("/api/shift-templates", async (req, res) => {
    try {
      const validatedData = insertShiftTemplateSchema.parse(req.body);
      const template = await storage.createShiftTemplate(validatedData);
      res.status(201).json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create shift template" });
    }
  });

  app.put("/api/shift-templates/:id", async (req, res) => {
    try {
      const validatedData = insertShiftTemplateSchema.partial().parse(req.body);
      const template = await storage.updateShiftTemplate(req.params.id, validatedData);
      
      if (!template) {
        return res.status(404).json({ message: "Shift template not found" });
      }
      
      res.json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update shift template" });
    }
  });

  app.delete("/api/shift-templates/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteShiftTemplate(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Shift template not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete shift template" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const employees = await storage.getAllEmployees();
      const shifts = await storage.getAllShifts();
      const today = new Date().toISOString().split('T')[0];
      const todayShifts = await storage.getShiftsByDate(today);
      const todayAttendance = await storage.getAttendanceByDate(today);
      
      const totalEmployees = employees.length;
      const activeShifts = todayShifts.length;
      
      // Calculate attendance rate
      const presentCount = todayAttendance.filter(att => att.status === 'present').length;
      const attendanceRate = todayAttendance.length > 0 ? Math.round((presentCount / todayAttendance.length) * 100) : 0;
      
      // Calculate coverage rate (simplified)
      const totalRequiredStaff = todayShifts.reduce((sum, shift) => sum + shift.requiredStaff, 0);
      const assignedStaff = await Promise.all(
        todayShifts.map(shift => storage.getShiftAssignmentsByShift(shift.id))
      );
      const totalAssignedStaff = assignedStaff.reduce((sum, assignments) => sum + assignments.length, 0);
      const coverageRate = totalRequiredStaff > 0 ? Math.round((totalAssignedStaff / totalRequiredStaff) * 100) : 0;
      
      res.json({
        totalEmployees,
        activeShifts,
        attendanceRate,
        coverageRate,
        pendingApprovals: 0 // Simplified for now
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
