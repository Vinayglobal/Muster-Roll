import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { format, addWeeks, subWeeks, startOfWeek, addDays } from "date-fns";
import ShiftCalendar from "@/components/shifts/shift-calendar";
import ShiftForm from "@/components/shifts/shift-form";
import { Shift, ShiftType } from "@shared/schema";

export default function Shifts() {
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date()));

  const { data: shifts = [] } = useQuery<Shift[]>({
    queryKey: ["/api/shifts"],
  });

  const { data: shiftTypes = [] } = useQuery<ShiftType[]>({
    queryKey: ["/api/shift-types"],
  });

  const weekStart = currentWeek;
  const weekEnd = addDays(weekStart, 6);

  const previousWeek = () => setCurrentWeek(subWeeks(currentWeek, 1));
  const nextWeek = () => setCurrentWeek(addWeeks(currentWeek, 1));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          {/* Shift Calendar */}
          <Card className="border border-gray-100">
            <CardHeader className="border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold text-gray-900">Shift Calendar</CardTitle>
                  <p className="text-sm text-gray-500">View and manage shift assignments</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={previousWeek}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium text-gray-900 px-4">
                    {format(weekStart, "MMM d")} - {format(weekEnd, "MMM d, yyyy")}
                  </span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={nextWeek}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <ShiftCalendar
                weekStart={weekStart}
                shifts={shifts}
                shiftTypes={shiftTypes}
              />
            </CardContent>
          </Card>
        </div>
        
        {/* Shift Form */}
        <div>
          <ShiftForm shiftTypes={shiftTypes} />
        </div>
      </div>
    </div>
  );
}
