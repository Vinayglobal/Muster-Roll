import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RefreshCw, Printer, Download } from "lucide-react";
import { format } from "date-fns";
import MusterTable from "@/components/muster/muster-table";
import { ShiftType } from "@shared/schema";

interface MusterRollEntry {
  employee: any;
  shift: any;
  assignment: any;
  attendance: any;
}

export default function MusterRoll() {
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [selectedShiftType, setSelectedShiftType] = useState<string>("shift-morning");

  const { data: shiftTypes = [] } = useQuery<ShiftType[]>({
    queryKey: ["/api/shift-types"],
  });

  const { data: musterRollData = [], isLoading, refetch } = useQuery<MusterRollEntry[]>({
    queryKey: ["/api/muster-roll", selectedDate, selectedShiftType],
    queryFn: async () => {
      const response = await fetch(`/api/muster-roll/${selectedDate}?shiftTypeId=${selectedShiftType}`);
      if (!response.ok) throw new Error("Failed to fetch muster roll");
      return response.json();
    },
  });

  const handleDateChange = (newDate: string) => {
    setSelectedDate(newDate);
  };

  const handleGenerate = () => {
    refetch();
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExport = () => {
    // Simple CSV export functionality
    const csvContent = [
      ["S.No.", "Employee ID", "Name", "Department", "Check In", "Check Out", "Status"],
      ...musterRollData.map((entry, index) => [
        index + 1,
        entry.employee?.employeeId || "",
        entry.employee?.name || "",
        entry.employee?.department || "",
        entry.attendance?.checkIn || "-",
        entry.attendance?.checkOut || "-",
        entry.attendance?.status || "absent"
      ])
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `muster-roll-${selectedDate}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const attendanceSummary = {
    present: musterRollData.filter(entry => entry.attendance?.status === "present").length,
    absent: musterRollData.filter(entry => !entry.attendance || entry.attendance.status === "absent").length,
    late: musterRollData.filter(entry => entry.attendance?.status === "late").length,
    total: musterRollData.length
  };

  return (
    <div className="space-y-6">
      <Card className="border border-gray-100">
        <CardHeader className="no-print border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold text-gray-900">Muster Roll</CardTitle>
              <p className="text-sm text-gray-500">Daily attendance tracking and reporting</p>
            </div>
            <div className="flex items-center space-x-2">
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => handleDateChange(e.target.value)}
                className="w-auto"
              />
              <Button
                onClick={handleGenerate}
                className="bg-blue-600 hover:bg-blue-700"
                disabled={isLoading}
              >
                <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                Generate
              </Button>
              <Button onClick={handlePrint} variant="outline">
                <Printer className="mr-2 h-4 w-4" />
                Print
              </Button>
              <Button onClick={handleExport} variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>

        {/* Print Header (only visible when printing) */}
        <div className="print-only p-6 text-center border-b border-gray-200">
          <h1 className="text-2xl font-bold text-gray-900">ABC Manufacturing Company</h1>
          <p className="text-lg text-gray-700">Daily Muster Roll</p>
          <p className="text-sm text-gray-600">Date: {format(new Date(selectedDate), "MMMM d, yyyy")}</p>
        </div>

        <CardContent className="p-0">
          <Tabs value={selectedShiftType} onValueChange={setSelectedShiftType} className="w-full">
            <TabsList className="grid w-full grid-cols-3 no-print">
              {shiftTypes.map((shiftType) => (
                <TabsTrigger key={shiftType.id} value={shiftType.id}>
                  {shiftType.name} ({shiftType.startTime}-{shiftType.endTime})
                </TabsTrigger>
              ))}
            </TabsList>

            {shiftTypes.map((shiftType) => (
              <TabsContent key={shiftType.id} value={shiftType.id} className="m-0">
                <MusterTable
                  data={musterRollData}
                  isLoading={isLoading}
                  shiftType={shiftType}
                />
              </TabsContent>
            ))}
          </Tabs>

          {/* Summary */}
          <div className="p-6 border-t border-gray-200 bg-gray-50">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{attendanceSummary.present}</p>
                <p className="text-sm text-gray-600">Present</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-red-600">{attendanceSummary.absent}</p>
                <p className="text-sm text-gray-600">Absent</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-600">{attendanceSummary.late}</p>
                <p className="text-sm text-gray-600">Late</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{attendanceSummary.total}</p>
                <p className="text-sm text-gray-600">Total</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
