import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, BarChart3, TrendingUp } from "lucide-react";
import { Employee, Attendance } from "@shared/schema";

const departments = [
  { value: "all", label: "All Departments" },
  { value: "production", label: "Production" },
  { value: "maintenance", label: "Maintenance" },
  { value: "quality", label: "Quality Control" },
  { value: "admin", label: "Administration" },
];

const dateRanges = [
  { value: "today", label: "Today" },
  { value: "week", label: "This Week" },
  { value: "month", label: "This Month" },
  { value: "quarter", label: "This Quarter" },
  { value: "custom", label: "Custom Range" },
];

const shifts = [
  { value: "all", label: "All Shifts" },
  { value: "morning", label: "Morning" },
  { value: "afternoon", label: "Afternoon" },
  { value: "night", label: "Night" },
];

interface EmployeeReport {
  employee: Employee;
  daysPresent: number;
  daysAbsent: number;
  lateDays: number;
  attendancePercentage: number;
}

export default function Reports() {
  const [selectedDateRange, setSelectedDateRange] = useState("month");
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [selectedShift, setSelectedShift] = useState("all");

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const { data: attendance = [] } = useQuery<Attendance[]>({
    queryKey: ["/api/attendance"],
  });

  // Generate report data based on employees and attendance
  const reportData: EmployeeReport[] = employees
    .filter(emp => !selectedDepartment || selectedDepartment === "all" || emp.department === selectedDepartment)
    .map(employee => {
      const employeeAttendance = attendance.filter(att => att.employeeId === employee.id);
      const daysPresent = employeeAttendance.filter(att => att.status === "present").length;
      const daysAbsent = employeeAttendance.filter(att => att.status === "absent").length;
      const lateDays = employeeAttendance.filter(att => att.status === "late").length;
      const totalDays = employeeAttendance.length || 1;
      const attendancePercentage = totalDays > 0 ? Math.round((daysPresent / totalDays) * 100) : 0;

      return {
        employee,
        daysPresent,
        daysAbsent,
        lateDays,
        attendancePercentage,
      };
    });

  const handleExportReport = () => {
    const csvContent = [
      ["Employee", "Department", "Days Present", "Days Absent", "Late Days", "Attendance %"],
      ...reportData.map(report => [
        report.employee.name,
        report.employee.department,
        report.daysPresent,
        report.daysAbsent,
        report.lateDays,
        `${report.attendancePercentage}%`
      ])
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `attendance-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getAttendanceColor = (percentage: number) => {
    if (percentage >= 90) return "bg-green-500";
    if (percentage >= 70) return "bg-yellow-500";
    return "bg-red-500";
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="space-y-6">
      {/* Report Filters */}
      <Card className="border border-gray-100">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">Report Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
              <Select value={selectedDateRange} onValueChange={setSelectedDateRange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {dateRanges.map(range => (
                    <SelectItem key={range.value} value={range.value}>
                      {range.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Department</label>
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.value} value={dept.value}>
                      {dept.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Shift</label>
              <Select value={selectedShift} onValueChange={setSelectedShift}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {shifts.map(shift => (
                    <SelectItem key={shift.value} value={shift.value}>
                      {shift.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button className="w-full bg-blue-600 hover:bg-blue-700" disabled>
                Generate Report
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Report Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <Card className="border border-gray-100">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Attendance Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-100 rounded-lg">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">Attendance trend chart would be displayed here</p>
                <p className="text-sm text-gray-400">Integration with charting library required</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border border-gray-100">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Department-wise Coverage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-100 rounded-lg">
              <div className="text-center">
                <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">Department coverage chart would be displayed here</p>
                <p className="text-sm text-gray-400">Integration with charting library required</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Detailed Report Table */}
      <Card className="border border-gray-100">
        <CardHeader className="border-b border-gray-200">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">Detailed Attendance Report</CardTitle>
            <Button onClick={handleExportReport} variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead>Employee</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Days Present</TableHead>
                  <TableHead>Days Absent</TableHead>
                  <TableHead>Late Days</TableHead>
                  <TableHead>Attendance %</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reportData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      <div className="text-gray-500">
                        No attendance data available for the selected filters.
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  reportData.map((report) => (
                    <TableRow key={report.employee.id} className="hover:bg-gray-50">
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                            <span className="text-xs font-medium text-gray-600">
                              {getInitials(report.employee.name)}
                            </span>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900">{report.employee.name}</p>
                            <p className="text-xs text-gray-500">{report.employee.employeeId}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="capitalize">{report.employee.department}</TableCell>
                      <TableCell>{report.daysPresent}</TableCell>
                      <TableCell>{report.daysAbsent}</TableCell>
                      <TableCell>{report.lateDays}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-gray-900">
                            {report.attendancePercentage}%
                          </span>
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${getAttendanceColor(report.attendancePercentage)}`}
                              style={{ width: `${report.attendancePercentage}%` }}
                            />
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
