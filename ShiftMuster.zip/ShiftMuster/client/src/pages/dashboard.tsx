import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Clock, AlertTriangle, Shield, Plus, Calendar, BarChart3, FileText, ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface DashboardStats {
  totalEmployees: number;
  activeShifts: number;
  attendanceRate: number;
  coverageRate: number;
  pendingApprovals: number;
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-16 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: "Total Employees",
      value: stats?.totalEmployees || 0,
      icon: Users,
      color: "bg-blue-100 text-blue-600",
      change: "+12 from last month"
    },
    {
      title: "Active Shifts",
      value: stats?.activeShifts || 0,
      icon: Clock,
      color: "bg-green-100 text-green-600",
      change: `${stats?.attendanceRate || 0}% attendance rate`
    },
    {
      title: "Pending Approvals",
      value: stats?.pendingApprovals || 0,
      icon: AlertTriangle,
      color: "bg-orange-100 text-orange-600",
      change: "3 urgent reviews"
    },
    {
      title: "Coverage Rate",
      value: `${stats?.coverageRate || 0}%`,
      icon: Shield,
      color: "bg-green-100 text-green-600",
      change: "+2% from last week"
    }
  ];

  const quickActions = [
    {
      title: "Generate Muster Roll",
      href: "/muster-roll",
      variant: "default" as const,
      icon: FileText
    },
    {
      title: "Add New Employee",
      href: "/employees",
      variant: "outline" as const,
      icon: Plus
    },
    {
      title: "Schedule Shift",
      href: "/shifts",
      variant: "outline" as const,
      icon: Calendar
    },
    {
      title: "View Reports",
      href: "/reports",
      variant: "outline" as const,
      icon: BarChart3
    }
  ];

  return (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border border-gray-100">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">{stat.title}</p>
                    <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${stat.color}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-green-600 font-medium">+2%</span>
                  <span className="text-gray-500 ml-1">{stat.change}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Today's Shift Overview */}
        <div className="xl:col-span-2">
          <Card className="border border-gray-100">
            <CardHeader className="border-b border-gray-200">
              <CardTitle className="text-lg font-semibold text-gray-900">Today's Shift Overview</CardTitle>
              <p className="text-sm text-gray-500">Current shift assignments and status</p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">M1</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Morning Shift</p>
                      <p className="text-sm text-gray-500">06:00 - 14:00</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">24/25</p>
                      <p className="text-xs text-gray-500">Assigned</p>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium status-active">
                      Active
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">A1</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Afternoon Shift</p>
                      <p className="text-sm text-gray-500">14:00 - 22:00</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">18/20</p>
                      <p className="text-xs text-gray-500">Assigned</p>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium status-pending">
                      Starting Soon
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center">
                      <span className="text-white font-medium text-sm">N1</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Night Shift</p>
                      <p className="text-sm text-gray-500">22:00 - 06:00</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">15/15</p>
                      <p className="text-xs text-gray-500">Assigned</p>
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-200 text-gray-600">
                      Scheduled
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Quick Actions */}
        <div>
          <Card className="border border-gray-100">
            <CardHeader className="border-b border-gray-200">
              <CardTitle className="text-lg font-semibold text-gray-900">Quick Actions</CardTitle>
              <p className="text-sm text-gray-500">Common tasks and shortcuts</p>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Link key={index} href={action.href}>
                    <Button 
                      variant={action.variant}
                      className="w-full justify-between h-auto p-4"
                    >
                      <div className="flex items-center space-x-3">
                        <Icon className="h-5 w-5" />
                        <span className="font-medium">{action.title}</span>
                      </div>
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                );
              })}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
