import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Calendar, Clock, BarChart3, Shield, ChevronRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">MusterPro</h1>
          </div>
          <Button onClick={() => window.location.href = "/api/login"} className="bg-blue-600 hover:bg-blue-700">
            Login to Continue
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-5xl font-bold text-gray-900 mb-6">
          Complete Workforce Management
        </h2>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          Streamline your employee shift scheduling, attendance tracking, and reporting with MusterPro - 
          the comprehensive solution for industrial workforce management.
        </p>
        <Button 
          size="lg" 
          onClick={() => window.location.href = "/api/login"}
          className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3"
        >
          Get Started <ChevronRight className="ml-2 h-5 w-5" />
        </Button>
      </section>

      {/* Features Grid */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Everything You Need to Manage Your Workforce
        </h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="text-center">
              <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <CardTitle>Employee Management</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Complete employee records, department organization, and status tracking
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="text-center">
              <Calendar className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <CardTitle>Shift Scheduling</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Visual calendar interface for creating and managing work shifts across departments
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="text-center">
              <Clock className="h-12 w-12 text-orange-600 mx-auto mb-4" />
              <CardTitle>Attendance Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Digital muster rolls with check-in/check-out times and attendance status
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader className="text-center">
              <BarChart3 className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <CardTitle>Reports & Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Comprehensive reporting with charts and insights for better decision making
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Key Benefits */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h3 className="text-3xl font-bold text-gray-900 mb-8">
              Why Choose MusterPro?
            </h3>
            <div className="grid md:grid-cols-3 gap-8 text-left">
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-4">Secure & Reliable</h4>
                <p className="text-gray-600">
                  Built with enterprise-grade security and reliable data management to protect your workforce information.
                </p>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-4">Easy to Use</h4>
                <p className="text-gray-600">
                  Intuitive interface designed for managers and supervisors to quickly manage schedules and track attendance.
                </p>
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-900 mb-4">Comprehensive</h4>
                <p className="text-gray-600">
                  All-in-one solution covering employee management, scheduling, attendance, and detailed reporting.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Shield className="h-6 w-6" />
            <span className="text-lg font-semibold">MusterPro</span>
          </div>
          <p className="text-gray-400">
            Professional workforce management for modern businesses
          </p>
        </div>
      </footer>
    </div>
  );
}