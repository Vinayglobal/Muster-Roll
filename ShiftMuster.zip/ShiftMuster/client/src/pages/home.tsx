import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import type { User } from "@shared/schema";
import { LogOut, User as UserIcon } from "lucide-react";

export default function Home() {
  const { user } = useAuth() as { user: User | undefined };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back{user?.firstName ? `, ${user.firstName}` : ''}!
          </h1>
          <p className="text-gray-600 mt-2">
            You are now logged in to MusterPro. Use the sidebar to navigate through the application.
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <UserIcon className="h-4 w-4" />
            <span>{user?.email}</span>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => window.location.href = "/api/logout"}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Getting Started</CardTitle>
          <CardDescription>
            Navigate through the application using the sidebar menu
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold mb-2">Quick Actions</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• View the Dashboard for overview and statistics</li>
                <li>• Manage Employees - add, edit, or view employee records</li>
                <li>• Schedule Shifts using the calendar interface</li>
                <li>• Track attendance with Muster Roll</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Advanced Features</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Generate Reports and analytics</li>
                <li>• Create Shift Templates for recurring schedules</li>
                <li>• Export data for external use</li>
                <li>• Print muster rolls and reports</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}