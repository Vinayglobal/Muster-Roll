import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2, Play } from "lucide-react";
import { ShiftTemplate } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface TemplateCardProps {
  template: ShiftTemplate;
  onEdit: (template: ShiftTemplate) => void;
  onDelete: (template: ShiftTemplate) => void;
  onApply: (template: ShiftTemplate) => void;
  isApplying: boolean;
}

export default function TemplateCard({ 
  template, 
  onEdit, 
  onDelete, 
  onApply, 
  isApplying 
}: TemplateCardProps) {
  const getLastUsedText = () => {
    if (!template.lastUsed) return "Never used";
    return `Last used: ${formatDistanceToNow(new Date(template.lastUsed), { addSuffix: true })}`;
  };

  const getTotalStaff = () => {
    return (template.morningStaff || 0) + (template.afternoonStaff || 0) + (template.nightStaff || 0);
  };

  return (
    <Card className="border border-gray-100 hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-900 truncate pr-2">
            {template.name}
          </h4>
          <div className="flex space-x-2 flex-shrink-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(template)}
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(template)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {template.description && (
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">
            {template.description}
          </p>
        )}
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Morning Shift:</span>
            <span className="font-medium">{template.morningStaff || 0} staff</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Afternoon Shift:</span>
            <span className="font-medium">{template.afternoonStaff || 0} staff</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Night Shift:</span>
            <span className="font-medium">{template.nightStaff || 0} staff</span>
          </div>
          <div className="flex items-center justify-between text-sm pt-2 border-t border-gray-200">
            <span className="text-gray-600 font-medium">Total Staff:</span>
            <span className="font-semibold text-gray-900">{getTotalStaff()} staff</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
          <Badge variant="outline" className="capitalize">
            {template.department}
          </Badge>
          <span>{getLastUsedText()}</span>
        </div>
        
        <Button
          className="w-full bg-blue-600 hover:bg-blue-700"
          onClick={() => onApply(template)}
          disabled={isApplying}
        >
          <Play className="mr-2 h-4 w-4" />
          {isApplying ? "Applying..." : "Apply Template"}
        </Button>
      </CardContent>
    </Card>
  );
}
