import { Link, useLocation } from "wouter";
import { Users, Calendar, ClipboardList, BarChart3, FileText, LayoutDashboard } from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Home", href: "/", icon: LayoutDashboard },
  { name: "Dashboard", href: "/dashboard", icon: BarChart3 },
  { name: "Employees", href: "/employees", icon: Users },
  { name: "Shift Scheduling", href: "/shifts", icon: Calendar },
  { name: "Muster Roll", href: "/muster-roll", icon: ClipboardList },
  { name: "Reports", href: "/reports", icon: BarChart3 },
  { name: "Shift Templates", href: "/templates", icon: FileText },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="bg-white shadow-lg w-64 sidebar-transition">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-musterpro-primary rounded-lg flex items-center justify-center">
            <Users className="text-white h-5 w-5" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-gray-900">MusterPro</h1>
            <p className="text-sm text-gray-500">Shift Management</p>
          </div>
        </div>
      </div>
      
      <nav className="p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <li key={item.name}>
                <Link href={item.href} className={cn(
                  "flex items-center px-4 py-3 rounded-lg font-medium transition-colors",
                  isActive
                    ? "text-blue-600 bg-blue-50"
                    : "text-gray-700 hover:text-blue-600 hover:bg-gray-50"
                )}>
                  <Icon className="mr-3 h-5 w-5" />
                  {item.name}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}
