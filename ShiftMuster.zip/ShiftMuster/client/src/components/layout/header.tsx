import { Search, Menu, User } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import type { User as UserType } from "@shared/schema";

const pageTitles = {
  "/": { title: "Home", subtitle: "Welcome to MusterPro workforce management" },
  "/dashboard": { title: "Dashboard", subtitle: "Overview of employee shifts and attendance" },
  "/employees": { title: "Employee Management", subtitle: "Manage employee profiles and information" },
  "/shifts": { title: "Shift Scheduling", subtitle: "Create and manage work shift assignments" },
  "/muster-roll": { title: "Muster Roll", subtitle: "Daily attendance tracking and reporting" },
  "/reports": { title: "Reports & Analytics", subtitle: "Attendance and shift coverage insights" },
  "/templates": { title: "Shift Templates", subtitle: "Manage recurring shift patterns" },
};

export default function Header() {
  const [location] = useLocation();
  const { user } = useAuth() as { user: UserType | undefined };
  const pageInfo = pageTitles[location as keyof typeof pageTitles] || pageTitles["/"];
  
  const getUserDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    } else if (user?.firstName) {
      return user.firstName;
    } else if (user?.email) {
      return user.email.split('@')[0];
    }
    return 'User';
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 no-print">
      <div className="px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="lg:hidden">
            <Menu className="h-5 w-5" />
          </Button>
          <div>
            <h2 className="text-2xl font-semibold text-gray-900">{pageInfo.title}</h2>
            <p className="text-sm text-gray-500">{pageInfo.subtitle}</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="search"
              placeholder="Search employees..."
              className="pl-10 pr-4 w-64"
            />
          </div>
          
          <div className="flex items-center space-x-2 bg-gray-50 px-3 py-2 rounded-lg">
            <User className="h-4 w-4 text-gray-500" />
            <span className="text-sm font-medium text-gray-700">{getUserDisplayName()}</span>
            <span className="text-xs text-gray-500">Admin</span>
          </div>
        </div>
      </div>
    </header>
  );
}
