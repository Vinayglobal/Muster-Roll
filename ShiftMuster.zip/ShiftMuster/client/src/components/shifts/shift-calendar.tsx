import { format, addDays, isToday } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Shift, ShiftType } from "@shared/schema";

interface ShiftCalendarProps {
  weekStart: Date;
  shifts: Shift[];
  shiftTypes: ShiftType[];
}

export default function ShiftCalendar({ weekStart, shifts, shiftTypes }: ShiftCalendarProps) {
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  
  const getShiftTypeById = (id: string) => shiftTypes.find(st => st.id === id);
  
  const getShiftsForDate = (date: Date, shiftTypeId: string) => {
    const dateStr = format(date, "yyyy-MM-dd");
    return shifts.filter(shift => shift.date === dateStr && shift.shiftTypeId === shiftTypeId);
  };

  const getShiftStatus = (assignedCount: number, requiredCount: number) => {
    const percentage = (assignedCount / requiredCount) * 100;
    if (percentage >= 90) return { variant: "default" as const, color: "bg-green-100 text-green-800" };
    if (percentage >= 70) return { variant: "secondary" as const, color: "bg-yellow-100 text-yellow-800" };
    return { variant: "destructive" as const, color: "bg-red-100 text-red-800" };
  };

  return (
    <div className="grid grid-cols-8 gap-4">
      {/* Header Row */}
      <div className="text-sm font-medium text-gray-500">Shift</div>
      {weekDays.map((day, index) => (
        <div key={index} className={`text-sm font-medium text-center ${isToday(day) ? 'text-blue-600' : 'text-gray-500'}`}>
          <div>{format(day, "EEE")}</div>
          <div className={`text-lg ${isToday(day) ? 'font-bold' : ''}`}>{format(day, "d")}</div>
        </div>
      ))}
      
      {/* Shift Rows */}
      {shiftTypes.map((shiftType) => (
        <div key={shiftType.id} className="contents">
          <div className="py-4 text-sm font-medium text-gray-900">
            {shiftType.name}
            <br />
            <span className="text-xs text-gray-500">{shiftType.startTime}-{shiftType.endTime}</span>
          </div>
          
          {weekDays.map((day, dayIndex) => {
            const dayShifts = getShiftsForDate(day, shiftType.id);
            const totalRequired = dayShifts.reduce((sum, shift) => sum + shift.requiredStaff, 0);
            const totalAssigned = dayShifts.length > 0 ? Math.floor(totalRequired * 0.9) : 0; // Simulated assigned count
            
            if (dayShifts.length === 0) {
              return (
                <div key={dayIndex} className="py-4 text-center">
                  <div className="bg-gray-100 text-gray-400 rounded-lg px-2 py-1 text-xs font-medium">
                    No shift
                  </div>
                </div>
              );
            }

            const status = getShiftStatus(totalAssigned, totalRequired);
            
            return (
              <div key={dayIndex} className="py-4 text-center">
                <div className={`rounded-lg px-2 py-1 text-xs font-medium ${status.color}`}>
                  {totalAssigned}/{totalRequired}
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
