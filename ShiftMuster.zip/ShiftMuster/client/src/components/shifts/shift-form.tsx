import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { insertShiftSchema, type InsertShift, type ShiftType, type Employee } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

const departments = [
  { value: "production", label: "Production" },
  { value: "maintenance", label: "Maintenance" },
  { value: "quality", label: "Quality Control" },
  { value: "admin", label: "Administration" },
];

interface ShiftFormProps {
  shiftTypes: ShiftType[];
}

export default function ShiftForm({ shiftTypes }: ShiftFormProps) {
  const [selectedEmployees, setSelectedEmployees] = useState<string[]>([]);
  const { toast } = useToast();

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const form = useForm<InsertShift>({
    resolver: zodResolver(insertShiftSchema),
    defaultValues: {
      shiftTypeId: "",
      date: format(new Date(), "yyyy-MM-dd"),
      department: "",
      requiredStaff: 1,
      notes: "",
    },
  });

  const createShiftMutation = useMutation({
    mutationFn: async (data: InsertShift) => {
      const response = await apiRequest("POST", "/api/shifts", data);
      return response.json();
    },
    onSuccess: (shift) => {
      // Create shift assignments for selected employees
      const assignmentPromises = selectedEmployees.map(employeeId =>
        apiRequest("POST", "/api/shift-assignments", {
          shiftId: shift.id,
          employeeId,
          status: "scheduled"
        })
      );
      
      Promise.all(assignmentPromises).then(() => {
        queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
        queryClient.invalidateQueries({ queryKey: ["/api/shift-assignments"] });
        toast({
          title: "Success",
          description: "Shift created and employees assigned successfully.",
        });
        form.reset();
        setSelectedEmployees([]);
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create shift.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertShift) => {
    createShiftMutation.mutate(data);
  };

  const handleEmployeeSelection = (employeeId: string, checked: boolean) => {
    if (checked) {
      setSelectedEmployees([...selectedEmployees, employeeId]);
    } else {
      setSelectedEmployees(selectedEmployees.filter(id => id !== employeeId));
    }
  };

  const isLoading = createShiftMutation.isPending;

  return (
    <Card className="border border-gray-100">
      <CardHeader className="border-b border-gray-200">
        <CardTitle className="text-lg font-semibold text-gray-900">Schedule New Shift</CardTitle>
        <p className="text-sm text-gray-500">Create or modify shift assignments</p>
      </CardHeader>
      
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="shiftTypeId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Shift Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select shift type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {shiftTypes.map(shiftType => (
                        <SelectItem key={shiftType.id} value={shiftType.id}>
                          {shiftType.name} ({shiftType.startTime}-{shiftType.endTime})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(new Date(field.value), "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value ? new Date(field.value) : undefined}
                        onSelect={(date) => field.onChange(date ? format(date, "yyyy-MM-dd") : "")}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="department"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Department</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {departments.map(dept => (
                        <SelectItem key={dept.value} value={dept.value}>
                          {dept.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="requiredStaff"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Required Staff</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="1"
                      max="50"
                      placeholder="Enter number of staff needed"
                      {...field}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div>
              <FormLabel>Assign Employees</FormLabel>
              <div className="space-y-2 max-h-40 overflow-y-auto border border-gray-300 rounded-lg p-3 mt-2">
                {employees.filter(emp => emp.status === 'active').map((employee) => (
                  <div key={employee.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={employee.id}
                      checked={selectedEmployees.includes(employee.id)}
                      onCheckedChange={(checked) => 
                        handleEmployeeSelection(employee.id, checked as boolean)
                      }
                    />
                    <label
                      htmlFor={employee.id}
                      className="text-sm text-gray-900 cursor-pointer flex-1"
                    >
                      {employee.name}
                      <span className="text-xs text-gray-500 ml-1">({employee.employeeId})</span>
                    </label>
                  </div>
                ))}
                {employees.filter(emp => emp.status === 'active').length === 0 && (
                  <p className="text-sm text-gray-500">No active employees found.</p>
                )}
              </div>
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="Additional notes or instructions..."
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-2">
              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? "Scheduling..." : "Schedule Shift"}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
