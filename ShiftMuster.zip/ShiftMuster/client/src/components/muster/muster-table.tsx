import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Edit, Eye } from "lucide-react";
import { ShiftType } from "@shared/schema";

interface MusterRollEntry {
  employee: any;
  shift: any;
  assignment: any;
  attendance: any;
}

interface MusterTableProps {
  data: MusterRollEntry[];
  isLoading: boolean;
  shiftType: ShiftType;
}

export default function MusterTable({ data, isLoading, shiftType }: MusterTableProps) {
  const [editingAttendance, setEditingAttendance] = useState<any>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "present": return "default";
      case "absent": return "destructive";
      case "late": return "secondary";
      case "partial": return "outline";
      default: return "destructive";
    }
  };

  const handleEditAttendance = (entry: MusterRollEntry) => {
    setEditingAttendance({
      employeeId: entry.employee.id,
      shiftId: entry.shift?.id,
      checkIn: entry.attendance?.checkIn || "",
      checkOut: entry.attendance?.checkOut || "",
      status: entry.attendance?.status || "absent",
      notes: entry.attendance?.notes || ""
    });
    setIsEditDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-gray-50">
              <TableHead>S.No.</TableHead>
              <TableHead>Employee ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Check In</TableHead>
              <TableHead>Check Out</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="no-print">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-8">
                  <div className="text-gray-500">
                    No employees assigned to this shift for the selected date.
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              data.map((entry, index) => (
                <TableRow key={entry.employee.id} className="hover:bg-gray-50">
                  <TableCell>{index + 1}</TableCell>
                  <TableCell className="font-mono text-sm">{entry.employee.employeeId}</TableCell>
                  <TableCell className="font-medium">{entry.employee.name}</TableCell>
                  <TableCell className="capitalize">{entry.employee.department}</TableCell>
                  <TableCell>{entry.attendance?.checkIn || "-"}</TableCell>
                  <TableCell>{entry.attendance?.checkOut || "-"}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(entry.attendance?.status || "absent")}>
                      {entry.attendance?.status || "Absent"}
                    </Badge>
                  </TableCell>
                  <TableCell className="no-print">
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditAttendance(entry)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Attendance Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Attendance</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Check In</label>
                <Input
                  type="time"
                  value={editingAttendance?.checkIn || ""}
                  onChange={(e) => setEditingAttendance({
                    ...editingAttendance,
                    checkIn: e.target.value
                  })}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">Check Out</label>
                <Input
                  type="time"
                  value={editingAttendance?.checkOut || ""}
                  onChange={(e) => setEditingAttendance({
                    ...editingAttendance,
                    checkOut: e.target.value
                  })}
                />
              </div>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <Select
                value={editingAttendance?.status || "absent"}
                onValueChange={(value) => setEditingAttendance({
                  ...editingAttendance,
                  status: value
                })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="present">Present</SelectItem>
                  <SelectItem value="absent">Absent</SelectItem>
                  <SelectItem value="late">Late</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Notes</label>
              <Input
                placeholder="Additional notes..."
                value={editingAttendance?.notes || ""}
                onChange={(e) => setEditingAttendance({
                  ...editingAttendance,
                  notes: e.target.value
                })}
              />
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => {
                // Here you would normally save the attendance
                setIsEditDialogOpen(false);
              }}>
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
