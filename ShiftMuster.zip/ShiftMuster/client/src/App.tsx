import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";

import Dashboard from "@/pages/dashboard";
import Employees from "@/pages/employees";
import Shifts from "@/pages/shifts";
import MusterRoll from "@/pages/muster-roll";
import Reports from "@/pages/reports";
import Templates from "@/pages/templates";
import Landing from "@/pages/landing";
import Home from "@/pages/home";

import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/employees" component={Employees} />
          <Route path="/shifts" component={Shifts} />
          <Route path="/muster-roll" component={MusterRoll} />
          <Route path="/reports" component={Reports} />
          <Route path="/templates" component={Templates} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthenticatedLayout />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function AuthenticatedLayout() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading || !isAuthenticated) {
    return <Router />;
  }

  return (
    <div className="flex h-screen overflow-hidden bg-musterpro-background">
      <Sidebar />
      <main className="flex-1 overflow-x-hidden overflow-y-auto">
        <Header />
        <div className="p-6">
          <Router />
        </div>
      </main>
    </div>
  );
}

export default App;
