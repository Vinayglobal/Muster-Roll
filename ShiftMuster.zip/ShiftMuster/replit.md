# MusterPro Shift Management System

## Overview

MusterPro is a comprehensive employee shift management and attendance tracking system designed for industrial workplaces. The application provides tools for managing employees, scheduling shifts, tracking attendance, and generating reports. It features a modern web interface built with React and TypeScript, backed by a PostgreSQL database with Drizzle ORM for type-safe database operations.

## User Preferences

Preferred communication style: Simple, everyday language.

## Base Version Status (August 2025)

The application has been successfully completed and tested with all core features working:
- ✅ Complete MusterPro workforce management system
- ✅ Employee management with CRUD operations
- ✅ Shift scheduling with calendar interface
- ✅ Muster roll generation and attendance tracking
- ✅ Reports and analytics with charts
- ✅ Shift templates for recurring patterns
- ✅ Professional UI with sidebar navigation
- ✅ All TypeScript errors resolved
- ✅ Console errors fixed
- ✅ **Authentication system with Replit Auth integration**
- ✅ **User session management and protected routes**
- ✅ **Dynamic user display showing actual logged-in username**
- ✅ **Tested with user "vinaykumardelhi61@gmail.com" successfully**

This version serves as the stable base for further customizations and is ready for ZIP download and offline deployment.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing without the complexity of React Router
- **State Management**: TanStack Query (React Query) for server state management, eliminating the need for complex state management libraries
- **UI Components**: Radix UI primitives with shadcn/ui component system for consistent, accessible design
- **Styling**: Tailwind CSS with custom CSS variables for theming and responsive design
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript for robust API development
- **Database ORM**: Drizzle ORM chosen for its type safety and SQL-like syntax that's easier to understand than complex query builders
- **API Design**: RESTful endpoints with consistent error handling and response formatting
- **Middleware**: Custom logging middleware for API request tracking and debugging
- **File Structure**: Organized with separate concerns - routes, storage layer, and database schema

### Database Design
- **Primary Database**: PostgreSQL for reliable ACID transactions and complex querying capabilities
- **Schema Management**: Drizzle Kit for database migrations and schema evolution
- **Connection**: Neon Database serverless PostgreSQL for scalable cloud deployment
- **Data Models**: 
  - Employees with department-based organization
  - Shift types defining work periods (morning, afternoon, night)
  - Shifts linking dates, departments, and staffing requirements
  - Shift assignments connecting employees to specific shifts
  - Attendance records for tracking actual work hours
  - Shift templates for recurring scheduling patterns

### Key Features
- **Employee Management**: Complete CRUD operations with department filtering and status tracking
- **Shift Scheduling**: Visual calendar interface for creating and managing work shifts
- **Attendance Tracking**: Digital muster roll with check-in/check-out times
- **Template System**: Reusable shift patterns for recurring schedules
- **Reporting**: Analytics and insights on attendance patterns and coverage
- **Responsive Design**: Mobile-friendly interface for field use

### Development Workflow
- **Development Server**: Vite dev server with hot module replacement
- **Type Checking**: Strict TypeScript configuration across frontend and backend
- **Database Operations**: Type-safe queries with Drizzle ORM and automatic schema validation
- **Error Handling**: Comprehensive error boundaries and API error responses

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle ORM**: Type-safe database toolkit with PostgreSQL dialect support

### UI and Styling
- **Radix UI**: Headless component primitives for accessibility and customization
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Consistent icon library for UI elements

### Development Tools
- **TanStack Query**: Server state management with caching and synchronization
- **React Hook Form**: Performance-focused form library with validation
- **Zod**: Runtime type validation for form inputs and API responses
- **date-fns**: Date manipulation and formatting utilities

### Build and Development
- **Vite**: Build tool with optimized development experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **TypeScript**: Static type checking across the entire application

### Deployment Considerations
- Application is configured for Replit deployment with development-specific plugins
- Environment variables required: DATABASE_URL for PostgreSQL connection
- Static asset serving configured for production builds
- Print-friendly CSS for generating physical muster rolls and reports